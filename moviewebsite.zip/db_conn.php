<?php
    $server = "localhost";
    $user = "root";
    $passwd = "pinky123!@#";
    $dbname = "dbms";

    $conn = mysqli_connect($server, $user, $passwd, $dbname);
    // if ($conn)
    // {
    //     echo "Connection Successfully Established";
    // }
    // else
    // {
    //     echo "Connection Refused";
    // }
	if($conn->connect_error){
		die("Connect failed". $conn->connect_error);
	}
	$query = "CREATE DATABASE IF NOT EXISTS dbms";
	if($conn->query($query) === TRUE){
		$query = "USE dbms";
		if($conn->query($query) === TRUE){
			$query = "create table web_series(
					ws_name varchar(50),
					ws_genre varchar(20),
					no_of_seasons int default 1,
					no_of_episodes int default 1,
					duration int default 60,
					ratings int default 1,
					ws_image varchar(150),
					ws_video varchar(150),
					pub_date date
			);";
			$conn->query($query);
			
			$users = "create table user(
				uname varchar(50) primary key,
				passwd varchar(50),
				conpasswd varchar(50),
				email varchar(70)
			);";
			$conn->query($users);
		}else{
			echo("not moved to dbms".$conn->error);
		}
	}else{
		echo("database not created".$conn->error);
	}
	$s = "SELECT ws_name, ws_genre,no_of_seasons,no_of_episodes,duration,ratings,ws_image,ws_video,pub_date from web_series";
	$r = mysqli_query($conn, $s);
	if(mysqli_num_rows($r)>0){
		while($rw = mysqli_fetch_assoc($r)){
			//echo "name: ".$rw["ws_name"]. "-genre: " . $rw["ws_genre"]. "seasons: ".$rw["no_of_seasons"]. "episodes: ".$rw["no_of_episodes"]. "time: ".$rw["duration
			echo "<table>";
		}
	}
	
?>